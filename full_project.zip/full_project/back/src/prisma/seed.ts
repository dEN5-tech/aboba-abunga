import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  const tickets = [
    {
      title: 'Первая заявка',
      description: 'Программа зависла',
      status: 'OPEN',
    },
    {
      title: 'Вторая заявка',
      description: 'Программа вылетела',
      status: 'IN_PROGRESS',
    },
    {
      title: 'Третья заявка',
      description: 'Ошибка при запуске',
      status: 'OPEN',
    },
    {
      title: 'Четвертая заявка',
      description: 'Не работает кнопка',
      status: 'CLOSED',
    },
    {
      title: 'Пятая заявка',
      description: 'Проблемы с сетью',
      status: 'IN_PROGRESS',
    },
    {
      title: 'Шестая заявка',
      description: 'Не удается сохранить файл',
      status: 'OPEN',
    },
    {
      title: 'Седьмая заявка',
      description: 'Программа зависает при загрузке',
      status: 'CLOSED',
    },
    {
      title: 'Восьмая заявка',
      description: 'Ошибка при установке',
      status: 'IN_PROGRESS',
    },
    {
      title: 'Девятая заявка',
      description: 'Не удается подключиться к серверу',
      status: 'OPEN',
    },
    {
      title: 'Десятая заявка',
      description: 'Программа вылетает при закрытии',
      status: 'CLOSED',
    },
  ];

  for (const ticket of tickets) {
    await prisma.ticket.create({
      data: ticket,
    });
  }

  console.log('Заявки успешно созданы');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });

