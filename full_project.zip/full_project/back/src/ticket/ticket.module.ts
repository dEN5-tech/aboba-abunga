import { Module } from '@nestjs/common';
import { TicketService } from './ticket.service';
import { TicketResolver } from './ticket.resolver';
import { PrismaService } from '../prisma/prisma.service'; // Import PrismaService
import { PrismaModule } from '../prisma/prisma.module'; // Import the module containing PrismaService

@Module({
  imports: [PrismaModule], // Add PrismaModule to imports
  providers: [TicketService, TicketResolver, PrismaService], // Add PrismaService to providers
  exports: [TicketService], // If other modules need to use TicketService
})
export class TicketModule {}