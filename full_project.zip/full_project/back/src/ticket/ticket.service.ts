import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { TicketInput } from './dto/ticket.input';

@Injectable()
export class TicketService {
  constructor(private prisma: PrismaService) {}

  async findAll() {
    return this.prisma.ticket.findMany({
      include: {
        TicketUser: {
          include: {
            user: true,
          },
        },
      },
    });
  }

  async findOneById(id: number) {
    return this.prisma.ticket.findUnique({
      where: { id: id },
      include: {
        TicketUser: {
          include: {
            user: true,
          },
        },
      },
    });
  }

  async create(input: TicketInput, userId: number) {
    const newTicket = await this.prisma.ticket.create({
      data: {
        title: input.title,
        description: input.description,
        status: input.status,
        createdAt: new Date(),
        updatedAt: new Date(),
        TicketUser: {
          create: {
            user: { connect: { id: userId } },
          },
        },
      },
    });
    return newTicket;
  }

  // Add more methods as needed
}

