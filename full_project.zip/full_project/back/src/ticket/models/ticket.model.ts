import { Field, ID, ObjectType } from '@nestjs/graphql';

@ObjectType()
export default class Ticket {
  @Field(() => ID, {
    description: `Айди тикета`,
  })
  id: string;

  @Field({
    description: `Заголовок тикета`,
  })
  title: string;

  @Field({
    description: `Описание тикета`,
  })
  description: string;

  @Field({
    description: `Перечисление статусов`,
  })
  status: string;

  @Field()
  createdAt: Date;

  @Field()
  updatedAt: Date;
}
