import { Resolver, Query, Args, Mutation, Subscription } from '@nestjs/graphql';
import { TicketService } from './ticket.service'; // Assuming you have a TicketService
import Ticket from './models/ticket.model'; // Corrected import for Ticket model
import { TicketInput } from './dto/ticket.input'; // Assuming you have a TicketInput DTO
import { PubSub } from 'graphql-subscriptions';

const pubSub = new PubSub();

@Resolver(() => Ticket)
export class TicketResolver {
  constructor(private readonly ticketService: TicketService) {}

  // Properly initialize the interval inside a lifecycle hook or method
  startPublishing() {
    setInterval(() => {
      this.ticketService.findAll().then((tickets) => {
        pubSub.publish('ticketCreated', { ticketCreated: tickets });
      });
    }, 1000);
  }

  @Query(() => [Ticket])
  async getTicketsFull(): Promise<Ticket[]> {
    const tickets = await this.ticketService.findAll();
    return tickets.map((ticket) => ({
      ...ticket,
      id: ticket.id.toString(),
    }));
  }

  @Query(() => Ticket, { nullable: false })
  async getTicket(@Args('id') id: string): Promise<Ticket> {
    const ticket = await this.ticketService.findOneById(parseInt(id));
    if (!ticket) {
      throw new Error(`Ticket with ID ${id} not found`);
    }
    return {
      ...ticket,
      id: ticket.id.toString(),
    };
  }

  @Mutation(() => Ticket)
  async createTicket(@Args('input') input: TicketInput): Promise<Ticket> {
    const createdTicket = await this.ticketService.create(input, 1);
    const ticketWithStringId = {
      ...createdTicket,
      id: createdTicket.id.toString(),
    };
    pubSub.publish('ticketCreated', { ticketCreated: ticketWithStringId });
    return ticketWithStringId;
  }

  

  @Subscription(() => Ticket)
  ticketCreated() {
    return pubSub.asyncIterator('ticketCreated');
  }
}
