import { InputType, Field } from '@nestjs/graphql';

@InputType()
export class TicketInput {
  @Field()
  title: string;

  @Field()
  description: string;

  @Field()
  status: string;
}