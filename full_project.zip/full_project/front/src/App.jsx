import { ChakraProvider, Box, Flex, Input, Button, FormControl, FormLabel } from '@chakra-ui/react';
import { Router, Route, Switch, Link } from 'wouter-preact';
import Home from './pages/Home';
import CreateTicket from './pages/CreateTicket';
import ViewTickets from './pages/ViewTickets';
import TicketDetails from './pages/TicketDetails';
import { useState } from 'preact/hooks';
import { USER_LOGIN } from './graphql/queries';
import { useMutation } from '@apollo/client';

function Sidebar() {
  return (
    <Box as="nav" p="4" bg="gray.800" color="white" minW="200px" h="100vh">
      <Flex direction="column" gap="4">
        <Link href="/">Home</Link>
        <Link href="/create-ticket">Create Ticket</Link>
        <Link href="/view-tickets">View Tickets</Link>
      </Flex>
    </Box>
  );
}


function LoginForm({ onLogin }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [login, { loading, error }] = useMutation(USER_LOGIN);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const { data } = await login({ variables: { email, password } });
      if (data.userLogin) {
        onLogin();
      }
    } catch (err) {
      console.error('Login failed', err);
    }
  };

  return (
    <Box as="form" onSubmit={handleSubmit} p="4" bg="gray.100" borderRadius="md" boxShadow="md">
      <FormControl id="email" mb="4">
        <FormLabel>Email</FormLabel>
        <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
      </FormControl>
      <FormControl id="password" mb="4">
        <FormLabel>Password</FormLabel>
        <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
      </FormControl>
      {error && <Box color="red.500" mb="4">Login failed. Please try again.</Box>}
      <Button type="submit" colorScheme="blue" width="full" isLoading={loading}>Login</Button>
    </Box>
  );
}

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  const handleLogin = () => {
    setIsAuthenticated(true);
  };

  return (
      <Flex h="100vh">
        {isAuthenticated ? (
          <>
            <Sidebar />
            <Box flex="1" p="4" h="100vh">
              <Router>
                <Switch>
                  <Route path="/" component={Home} />
                  <Route path="/create-ticket" component={CreateTicket} />
                  <Route path="/view-tickets" component={ViewTickets} />
                  <Route path="/ticket/:id" component={TicketDetails} />
                  <Route>404: Page Not Found</Route>
                </Switch>
              </Router>
            </Box>
          </>
        ) : (
          <Box flex="1" display="flex" alignItems="center" justifyContent="center">
            <LoginForm onLogin={handleLogin} />
          </Box>
        )}
      </Flex>
  );
}

export default App;