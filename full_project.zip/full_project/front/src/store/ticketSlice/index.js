import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { GET_TICKETS_FULL } from '../../graphql/queries';
import { client } from '../..';

const initialState = {
  tickets: [],
  loading: false,
  error: null,
};

export const fetchTickets = createAsyncThunk(
  'tickets/fetchTickets',
  async (_, { rejectWithValue }) => {
    try {
      if (!client || !client.query) {
        throw new Error('Apollo client is not properly initialized');
      }
      const response = await client.query({
        query: GET_TICKETS_FULL,
      });
      return response.data.getTicketsFull;
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);

const ticketSlice = createSlice({
  name: 'tickets',
  initialState,
  reducers: {
    addTicket(state, action) {
      state.tickets.push(action.payload);
    },
    removeTicket(state, action) {
      state.tickets = state.tickets.filter(ticket => ticket.id !== action.payload);
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchTickets.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchTickets.fulfilled, (state, action) => {
        state.loading = false;
        state.tickets = action.payload;
      })
      .addCase(fetchTickets.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
  },
});

export const {
  addTicket,
  removeTicket,
} = ticketSlice.actions;

export const ticketReducer = ticketSlice.reducer;
