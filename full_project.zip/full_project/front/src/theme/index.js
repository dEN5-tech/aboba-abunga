import { extendTheme } from '@chakra-ui/react';

const theme = extendTheme({
  colors: {
    primary: {
      100: '#1a1a1a', // Фон
      200: '#e0e0e0', // Основной текст
      300: '#b0b0b0', // Второстепенный текст
      400: '#ffffff', // Заголовки
      500: '#1e88e5', // Кнопки
    },
    background: '#1a1a1a',
    text: {
      main: '#e0e0e0',
      secondary: '#b0b0b0',
    },
    header: '#ffffff',
    button: {
      default: '#1e88e5',
      hover: '#1565c0', // Adjusted in styles
    },
    input: {
      field: '#333333', // lighten(#1a1a1a, 10%)
      border: '#555555', // lighten(#1a1a1a, 20%)
    },
    card: {
      background: '#2a2a2a', // darken(#1a1a1a, 10%)
      shadow: '#000000',
    },
    status: {
      new: '#FFEB3B',
      inProgress: '#FF9800',
      resolved: '#4CAF50',
      closed: '#F44336',
    },
    link: {
      default: '#1e88e5',
      hover: '#1565c0', // Adjusted in styles
    },
    error: '#D32F2F',
    success: '#388E3C',
    warning: '#FFA000',
    info: '#1976D2',
  },
  styles: {
    global: {
      'button:hover': {
        backgroundColor: '#1565c0', // darken(#1e88e5, 10%)
      },
      'a:hover': {
        color: '#1565c0', // darken(#1e88e5, 10%)
      },
    },
  },
});

export default theme;