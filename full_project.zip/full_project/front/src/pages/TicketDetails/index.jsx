import { Box, Heading, Text } from '@chakra-ui/react';
import { useQuery } from '@apollo/client';
import { useRoute } from 'wouter-preact';
import { GET_TICKET } from '../../graphql/queries';

function TicketDetails() {
  const [match, params] = useRoute('/ticket/:id');
  const ticketId = params.id.toString();
  const { data, loading, error } = useQuery(GET_TICKET, { variables: { id: ticketId } });

  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error: {error.message}</p>;

  const ticket = data?.getTicket;

  return (
    <Box p={5}>
      <Heading>{ticket.title}</Heading>
      <Text mt={4}>{ticket.description}</Text>
      <Text mt={4}>{ticket.status}</Text>
      <Text mt={4}>{ticket.createdAt}</Text>
      <Text mt={4}>{ticket.updatedAt}</Text>
    </Box>
  );
}

export default TicketDetails;