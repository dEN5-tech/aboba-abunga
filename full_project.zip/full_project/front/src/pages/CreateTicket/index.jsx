import { useMutation, useSubscription } from '@apollo/client';
import { Box, Heading, Input, Textarea, Button } from '@chakra-ui/react';
import { CREATE_TICKET, TICKET_CREATED } from '../../graphql/queries';
import { useState,useEffect } from 'preact/hooks';

function CreateTicket() {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [status, setStatus] = useState('');
  const [createTicket] = useMutation(CREATE_TICKET);
  const [ticketCreatedData, setTicketCreatedData] = useState([]);

  const { loading: ticketCreatedLoading, error: ticketCreatedError, data: ticketCreatedDataSubscription } = useSubscription(
    TICKET_CREATED
  );

  useEffect(() => {
    if (ticketCreatedDataSubscription) {
      setTicketCreatedData(prev => [...prev, ticketCreatedDataSubscription.ticketCreated]);
    }
  }, [ticketCreatedDataSubscription]);

  function handleSubmit() {
    createTicket({ variables: { title, description, status } });
  }

  return (
    <Box p={5}>
      <Heading>Create a New Ticket</Heading>
      <Input placeholder="Title" mt={4} onChange={(e) => setTitle(e.target.value)} />
      <Textarea placeholder="Description" mt={4} onChange={(e) => setDescription(e.target.value)} />
      <Textarea placeholder="Status" mt={4} onChange={(e) => setStatus(e.target.value)} />
      <Button mt={4} onClick={handleSubmit} colorScheme="blue">Submit</Button>
    </Box>
  );
}

export default CreateTicket;