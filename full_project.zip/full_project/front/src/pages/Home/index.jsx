import { Box, Heading, Link } from '@chakra-ui/react';
import { Link as WouterLink } from 'wouter-preact';
import { useEffect, useState } from 'preact/hooks';

function Home() {
  


  return (
    <Box p={5}>
      <Heading>Welcome to the Support App</Heading>
      <Link as={WouterLink} href="/create-ticket">Create a Ticket</Link>
      <br />
      <Link as={WouterLink} href="/view-tickets">View Tickets</Link>
    </Box>
  );
}

export default Home;