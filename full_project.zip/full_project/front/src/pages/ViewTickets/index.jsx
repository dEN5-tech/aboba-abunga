import { Box, Heading, Grid, Spinner, Alert, AlertIcon, Link } from '@chakra-ui/react';
import { Link as WouterLink } from 'wouter-preact';
import { useEffect } from 'preact/hooks';
import { useDispatch, useSelector } from 'react-redux';
import { fetchTickets } from '../../store/ticketSlice';
import { motion } from 'framer-motion';
import { Card, CardHeader, CardBody } from '@chakra-ui/react';
import { Badge } from '@chakra-ui/react';

function ViewTickets() {
  const dispatch = useDispatch();
  const { tickets, loading, error } = useSelector(state => state.ticket);

  useEffect(() => {
    dispatch(fetchTickets());
  }, [dispatch]);

  if (loading) {
    return <Spinner />;
  }

  if (error) {
    return (
      <Alert status="error">
        <AlertIcon />
        {error}
      </Alert>
    );
  }

  return (
    <Box p={5}>
      <Heading>View Tickets</Heading>
      <Grid templateColumns="repeat(auto-fill, minmax(250px, 1fr))" gap={6} mt={4}>
        {tickets.map(ticket => (
        <motion.div key={ticket.id} whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
        <Card>
          <CardHeader>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <Link as={WouterLink} href={`/ticket/${ticket.id}`}>
                {ticket.title}
              </Link>
              <span>{ticket.date}</span>
            </div>
            <div>{ticket.user}</div>
          </CardHeader>
          <CardBody>
            <p>{ticket.description}</p>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <Badge color="red">{ticket.priority}</Badge>
                <Badge color="green">{ticket.status}</Badge>
              </div>
              <div>
                <span>{ticket.comments} comments</span>
              </div>
            </div>
          </CardBody>
        </Card>
      </motion.div>
        ))}
      </Grid>
    </Box>
  );
}

export default ViewTickets;