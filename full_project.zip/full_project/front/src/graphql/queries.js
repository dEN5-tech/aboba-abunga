import { gql } from "@apollo/client";

export const GET_TICKETS_FULL = gql`
  query GetTicketsFull {
    getTicketsFull {
      id
      title
      description
      status
      createdAt
      updatedAt
    }
  }
`;

export const GET_TICKET = gql`
  query GetTicket($id: String!) {
    getTicket(id: $id) {
      id
      title
      description
      status
      createdAt
      updatedAt
    }
  }
`;

export const CREATE_TICKET = gql`
  mutation CreateTicket($title: String!, $description: String!, $status: String!) {
    createTicket(input: {title: $title, description: $description, status: $status}) {
      id
      title
      description
      status
      createdAt
      updatedAt
    }
  }
`;

export const TICKET_CREATED = gql`
subscription {
    ticketCreated {
      id
      title
      description
      status
      createdAt
      updatedAt
    }
  }
`;

export const USER_LOGIN = gql`
  mutation UserLogin($email: String!, $password: String!) {
    userLogin(input: {email: $email, password: $password}) {
      id
      email
      name
    }
  }
`;